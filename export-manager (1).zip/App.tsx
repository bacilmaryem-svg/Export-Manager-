import React, { useState } from 'react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import CreateDossier from './components/CreateDossier';
import DossierDetail from './components/DossierDetail';
import { Dossier, UserRole, DossierStatus } from './types';

// Mock Initial Data
const INITIAL_DOSSIERS: Dossier[] = [
  {
    id: 'EXP-2024-001',
    reference: 'PO-9981-A',
    destination: 'Valencia, Spain',
    incoterm: 'FOB',
    supplier: 'Atlantic Exports Ltd',
    consignee: 'Mercadona S.A.',
    plannedContainers: 2,
    containerType: '40RF',
    transportMode: 'CONTAINER',
    notes: 'Urgent shipment, temperature recorder required.',
    status: DossierStatus.READY_FOR_DECLARATION,
    lastUpdated: '2024-05-14',
    createdAt: '2024-05-01',
    totalCartons: 4200,
    totalNet: 24000,
    totalGross: 25200,
    totalValue: 145000
  },
  {
    id: 'EXP-2024-002',
    reference: 'BK-NY-221',
    destination: 'New York, USA',
    incoterm: 'CIF',
    supplier: 'Atlantic Exports Ltd',
    consignee: 'Whole Foods Market',
    plannedContainers: 1,
    containerType: '40HC',
    transportMode: 'CONTAINER',
    notes: 'Requires FDA Prior Notice.',
    status: DossierStatus.WAITING_PRODUCTION_LOTS,
    lastUpdated: '2024-05-15',
    createdAt: '2024-05-10',
    totalCartons: 0,
    totalNet: 0,
    totalGross: 0,
    totalValue: 0
  },
  {
    id: 'EXP-2024-003',
    reference: 'PO-ASIA-88',
    destination: 'Shanghai, China',
    incoterm: 'CFR',
    supplier: 'Atlantic Exports Ltd',
    consignee: 'Shanghai Trading Co.',
    plannedContainers: 3,
    containerType: '40RF',
    transportMode: 'CONTAINER',
    notes: '',
    status: DossierStatus.SUBMITTED,
    lastUpdated: '2024-05-12',
    createdAt: '2024-04-28',
    totalCartons: 6300,
    totalNet: 36000,
    totalGross: 37800,
    totalValue: 210000,
    dum: 'DUM-SH-2024-X99',
    submissionDate: '2024-05-11'
  }
];

type ViewState = 'LOGIN' | 'DASHBOARD' | 'CREATE' | 'DETAIL';

const App: React.FC = () => {
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [view, setView] = useState<ViewState>('LOGIN');
  const [dossiers, setDossiers] = useState<Dossier[]>(INITIAL_DOSSIERS);
  const [selectedDossierId, setSelectedDossierId] = useState<string | null>(null);

  const handleLogin = (role: UserRole) => {
    setUserRole(role);
    setView('DASHBOARD');
  };

  const handleLogout = () => {
    setUserRole(null);
    setSelectedDossierId(null);
    setView('LOGIN');
  };

  const handleCreateDossier = (data: Partial<Dossier>) => {
    const newDossier: Dossier = {
      id: `EXP-2024-00${dossiers.length + 1}`,
      reference: data.reference || '',
      destination: data.destination || '',
      incoterm: data.incoterm || 'FOB',
      supplier: data.supplier || 'Atlantic Exports Ltd',
      consignee: data.consignee || '',
      plannedContainers: data.plannedContainers || 1,
      containerType: data.containerType || '40HC',
      transportMode: data.transportMode || 'CONTAINER',
      truckPlate: data.truckPlate,
      notes: data.notes || '',
      status: DossierStatus.DRAFT,
      lastUpdated: new Date().toISOString().split('T')[0],
      createdAt: new Date().toISOString().split('T')[0],
      totalCartons: 0,
      totalNet: 0,
      totalGross: 0,
      totalValue: 0
    };
    setDossiers([newDossier, ...dossiers]);
    setView('DASHBOARD');
  };

  const handleUpdateDossier = (id: string, updates: Partial<Dossier>) => {
    setDossiers(prev => prev.map(d => 
      d.id === id ? { ...d, ...updates, lastUpdated: new Date().toISOString().split('T')[0] } : d
    ));
  };

  const renderView = () => {
    switch (view) {
      case 'LOGIN':
        return <Login onLogin={handleLogin} />;
      
      case 'DASHBOARD':
        return (
          <Dashboard 
            role={userRole!} 
            dossiers={dossiers} 
            onSelectDossier={(id) => {
              setSelectedDossierId(id);
              setView('DETAIL');
            }}
            onCreateDossier={() => setView('CREATE')}
          />
        );

      case 'CREATE':
        return (
          <CreateDossier 
            onCancel={() => setView('DASHBOARD')}
            onSubmit={handleCreateDossier}
          />
        );

      case 'DETAIL':
        const selected = dossiers.find(d => d.id === selectedDossierId);
        if (!selected) return <div>Dossier not found</div>;
        return (
          <DossierDetail 
            dossier={selected}
            role={userRole!}
            onUpdate={(updates) => handleUpdateDossier(selected.id, updates)}
          />
        );
      
      default:
        return <div>Unknown view</div>;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans">
      {/* Navbar if logged in */}
      {view !== 'LOGIN' && (
        <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
            <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setView('DASHBOARD')}>
              <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
                 <i className="fa-solid fa-ship"></i>
              </div>
              <h1 className="text-lg font-black tracking-tight text-slate-900">Export Manager</h1>
            </div>
            <div className="flex items-center space-x-6">
              <div className="text-right hidden md:block">
                <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Logged in as</p>
                <p className="text-sm font-bold text-slate-900">{userRole === UserRole.EXPORT_OPS ? 'Operations Manager' : 'Government Declarant'}</p>
              </div>
              <button 
                onClick={handleLogout}
                className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 hover:bg-slate-200 hover:text-slate-700 transition-colors"
                title="Logout"
              >
                <i className="fa-solid fa-power-off"></i>
              </button>
            </div>
          </div>
        </nav>
      )}

      {/* Main Layout */}
      <main className={`${view !== 'LOGIN' ? 'max-w-7xl mx-auto px-6 py-8' : ''}`}>
        {view === 'DETAIL' && (
          <button 
            onClick={() => setView('DASHBOARD')}
            className="mb-6 flex items-center space-x-2 text-slate-500 hover:text-indigo-600 transition-colors font-bold text-sm"
          >
            <i className="fa-solid fa-arrow-left"></i>
            <span>Back to Dashboard</span>
          </button>
        )}
        {renderView()}
      </main>
    </div>
  );
};

export default App;