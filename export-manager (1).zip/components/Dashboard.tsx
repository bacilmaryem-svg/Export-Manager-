import React, { useState, useMemo } from 'react';
import { Dossier, DossierStatus, UserRole } from '../types';

interface DashboardProps {
  role: UserRole;
  dossiers: Dossier[];
  onSelectDossier: (id: string) => void;
  onCreateDossier: () => void;
}

const StatusBadge: React.FC<{ status: DossierStatus }> = ({ status }) => {
  const styles: Record<DossierStatus, string> = {
    [DossierStatus.DRAFT]: 'bg-slate-100 text-slate-700',
    [DossierStatus.WAITING_PRODUCTION_LOTS]: 'bg-amber-100 text-amber-700 border-amber-200',
    [DossierStatus.LOTS_APPROVED]: 'bg-blue-100 text-blue-700 border-blue-200',
    [DossierStatus.PL_READY]: 'bg-indigo-100 text-indigo-700 border-indigo-200',
    [DossierStatus.VGM_READY]: 'bg-teal-100 text-teal-700 border-teal-200',
    [DossierStatus.REGULATORY_READY]: 'bg-violet-100 text-violet-700 border-violet-200',
    [DossierStatus.READY_FOR_DECLARATION]: 'bg-green-100 text-green-700 border-green-200',
    [DossierStatus.SUBMITTED]: 'bg-cyan-100 text-cyan-700 border-cyan-200',
    [DossierStatus.CLEARED]: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    [DossierStatus.BLOCKED]: 'bg-rose-100 text-rose-700 border-rose-200 animate-pulse',
  };

  const getStatusLabel = (s: DossierStatus) => {
    if (s === DossierStatus.READY_FOR_DECLARATION) return "READY FOR GOV PORTAL";
    if (s === DossierStatus.CLEARED) return "ACCEPTED / CLEARED";
    return s.replace(/_/g, ' ');
  };

  return (
    <span className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider border ${styles[status]}`}>
      {getStatusLabel(status)}
    </span>
  );
};

const Dashboard: React.FC<DashboardProps> = ({ role, dossiers, onSelectDossier, onCreateDossier }) => {
  const [filter, setFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  const filteredDossiers = useMemo(() => {
    return dossiers.filter(d => {
      const matchSearch = d.id.toLowerCase().includes(filter.toLowerCase()) || 
                          d.reference.toLowerCase().includes(filter.toLowerCase()) ||
                          d.destination.toLowerCase().includes(filter.toLowerCase());
      const matchStatus = statusFilter === 'ALL' || d.status === statusFilter;
      return matchSearch && matchStatus;
    });
  }, [dossiers, filter, statusFilter]);

  const stats = useMemo(() => ({
    total: dossiers.length,
    ready: dossiers.filter(d => d.status === DossierStatus.READY_FOR_DECLARATION).length,
    waiting: dossiers.filter(d => d.status === DossierStatus.WAITING_PRODUCTION_LOTS).length,
    blocked: dossiers.filter(d => d.status === DossierStatus.BLOCKED).length,
  }), [dossiers]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
            {role === UserRole.EXPORT_OPS ? 'Operations Dashboard' : 'Gov Portal Upload Dashboard'}
          </h2>
          <p className="text-slate-500 text-sm font-medium mt-1">Manage maritime dossiers and regulatory compliance.</p>
        </div>
        {role === UserRole.EXPORT_OPS && (
          <button 
            onClick={onCreateDossier}
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-indigo-600/30 transition-all flex items-center space-x-2"
          >
            <i className="fa-solid fa-plus"></i>
            <span>Create New Dossier</span>
          </button>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">Total Active</p>
          <div className="flex items-end justify-between mt-2">
            <h3 className="text-3xl font-black text-slate-900">{stats.total}</h3>
            <span className="text-indigo-600 font-bold text-xs bg-indigo-50 px-2 py-1 rounded">Dossiers</span>
          </div>
        </div>
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 border-l-4 border-l-amber-500">
          <p className="text-xs font-bold text-amber-600 uppercase tracking-widest">Waiting Production</p>
          <div className="flex items-end justify-between mt-2">
            <h3 className="text-3xl font-black text-slate-900">{stats.waiting}</h3>
            <span className="text-amber-600 font-bold text-xs bg-amber-50 px-2 py-1 rounded">Pending</span>
          </div>
        </div>
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 border-l-4 border-l-green-500">
          <p className="text-xs font-bold text-green-600 uppercase tracking-widest">Ready for Gov Portal</p>
          <div className="flex items-end justify-between mt-2">
            <h3 className="text-3xl font-black text-slate-900">{stats.ready}</h3>
            <span className="text-green-600 font-bold text-xs bg-green-50 px-2 py-1 rounded">Compliant</span>
          </div>
        </div>
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 border-l-4 border-l-rose-500">
          <p className="text-xs font-bold text-rose-600 uppercase tracking-widest">Blocked</p>
          <div className="flex items-end justify-between mt-2">
            <h3 className="text-3xl font-black text-slate-900">{stats.blocked}</h3>
            <span className="text-rose-600 font-bold text-xs bg-rose-50 px-2 py-1 rounded">Attention</span>
          </div>
        </div>
      </div>

      {/* Filters & Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center space-x-4">
          <div className="flex-1 relative">
            <i className="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
            <input 
              type="text" 
              placeholder="Search by ID, Reference or Destination..." 
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            />
          </div>
          <select 
             className="bg-slate-50 border border-slate-200 rounded-lg text-sm px-4 py-2 focus:outline-none"
             value={statusFilter}
             onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="ALL">All Statuses</option>
            {Object.values(DossierStatus).map(s => (
              <option key={s} value={s}>
                {s === DossierStatus.READY_FOR_DECLARATION ? "READY FOR GOV PORTAL" : 
                 s === DossierStatus.CLEARED ? "ACCEPTED / CLEARED" : s.replace(/_/g, ' ')}
              </option>
            ))}
          </select>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">ID / Ref</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Destination</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Status</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Logistics</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Last Update</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDossiers.map((dossier) => (
                <tr key={dossier.id} className="hover:bg-slate-50/80 transition-colors group">
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className="font-bold text-slate-900 text-sm group-hover:text-indigo-600 transition-colors">{dossier.id}</span>
                      <span className="text-xs text-slate-500 font-medium">Ref: {dossier.reference}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-2">
                       <i className="fa-solid fa-location-dot text-slate-400 text-xs"></i>
                       <span className="text-sm font-medium text-slate-700">{dossier.destination}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <StatusBadge status={dossier.status} />
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-3">
                      <div className="flex flex-col">
                        <span className="text-xs font-bold text-slate-700">{dossier.plannedContainers} x {dossier.containerType}</span>
                        <span className="text-[10px] text-slate-500 uppercase font-bold tracking-tight">{dossier.incoterm}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-xs font-medium text-slate-600 italic">{dossier.lastUpdated}</span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button 
                      onClick={() => onSelectDossier(dossier.id)}
                      className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border border-slate-200"
                    >
                      Open Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredDossiers.length === 0 && (
            <div className="p-12 text-center text-slate-400">
              <i className="fa-solid fa-box-open text-4xl mb-4 opacity-20"></i>
              <p className="text-sm font-medium">No dossiers found matching your criteria.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;