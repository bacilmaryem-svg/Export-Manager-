import React, { useState } from 'react';
import { UserRole } from '../types';

interface LoginProps {
  onLogin: (role: UserRole) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate network delay for realism
    setTimeout(() => {
      // Mock Authentication Logic
      // In a real app, this would validate against a backend API
      if (username === 'admin' && password === 'admin') {
        onLogin(UserRole.EXPORT_OPS);
      } else if (username === 'user' && password === 'user') {
        onLogin(UserRole.DECLARANT_ETAT);
      } else {
        setError('Invalid username or password.');
        setIsLoading(false);
      }
    }, 800);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-6">
      <div className="max-w-md w-full animate-in fade-in zoom-in duration-500">
        <div className="text-center mb-10">
           <div className="w-20 h-20 bg-indigo-600 rounded-3xl mx-auto flex items-center justify-center shadow-2xl shadow-indigo-500/50 mb-6">
              <i className="fa-solid fa-ship text-3xl text-white"></i>
           </div>
           <h1 className="text-4xl font-black text-white tracking-tight">Export Manager</h1>
           <p className="text-slate-400 font-medium mt-2">Dossier management & regulatory compliance</p>
        </div>

        <div className="bg-slate-800 border border-slate-700 rounded-3xl p-8 shadow-2xl">
          <p className="text-xs font-bold text-slate-500 uppercase tracking-widest text-center mb-8">Secure Access Portal</p>
          
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Username</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <i className="fa-solid fa-user text-slate-500"></i>
                </div>
                <input
                  type="text"
                  required
                  className="w-full bg-slate-900 border border-slate-600 text-white text-sm rounded-xl focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 p-3 placeholder-slate-600 transition-colors"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Password</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <i className="fa-solid fa-lock text-slate-500"></i>
                </div>
                <input
                  type="password"
                  required
                  className="w-full bg-slate-900 border border-slate-600 text-white text-sm rounded-xl focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-10 p-3 placeholder-slate-600 transition-colors"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>

            {error && (
              <div className="bg-rose-500/10 border border-rose-500/20 rounded-lg p-3 flex items-center space-x-2 animate-in fade-in slide-in-from-top-1">
                <i className="fa-solid fa-circle-exclamation text-rose-500 text-xs"></i>
                <p className="text-xs text-rose-400 font-bold">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full text-white bg-indigo-600 hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-800 font-bold rounded-xl text-sm px-5 py-3.5 mr-2 mb-2 focus:outline-none shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center space-x-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <i className="fa-solid fa-circle-notch fa-spin"></i>
                  <span>Authenticating...</span>
                </>
              ) : (
                <>
                  <span>Login to Dashboard</span>
                  <i className="fa-solid fa-arrow-right"></i>
                </>
              )}
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-slate-700">
             <div className="flex justify-between items-center text-[10px] text-slate-500 uppercase font-bold tracking-widest mb-3">
                <span>Demo Credentials</span>
             </div>
             <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="bg-slate-900/50 p-3 rounded-xl border border-slate-700/50">
                    <span className="block text-[9px] text-indigo-400 font-bold uppercase mb-1">Admin (Ops)</span>
                    <div className="text-slate-400 font-mono">admin / admin</div>
                </div>
                <div className="bg-slate-900/50 p-3 rounded-xl border border-slate-700/50">
                    <span className="block text-[9px] text-indigo-400 font-bold uppercase mb-1">User (Declarant)</span>
                    <div className="text-slate-400 font-mono">user / user</div>
                </div>
             </div>
          </div>
        </div>

        <p className="text-center text-slate-600 text-xs font-medium mt-8">
          By logging in, you agree to the regulatory tracking and audit log policies.
        </p>
      </div>
    </div>
  );
};

export default Login;