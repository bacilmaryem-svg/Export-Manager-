import React, { useState } from 'react';
import { Dossier } from '../types';

interface CreateDossierProps {
  onCancel: () => void;
  onSubmit: (dossier: Partial<Dossier>) => void;
}

const CreateDossier: React.FC<CreateDossierProps> = ({ onCancel, onSubmit }) => {
  const [formData, setFormData] = useState<Partial<Dossier>>({
    reference: '',
    destination: '',
    incoterm: 'FOB',
    supplier: 'Atlantic Exports Ltd',
    consignee: '',
    transportMode: 'CONTAINER',
    plannedContainers: 1,
    containerType: '40HC',
    truckPlate: '',
    notes: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'plannedContainers' ? parseInt(value) : value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="max-w-3xl mx-auto animate-in slide-in-from-bottom-4 duration-500">
      <div className="bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="bg-slate-900 p-8 text-white relative">
           <div className="absolute top-0 right-0 p-8 opacity-10">
              <i className="fa-solid fa-ship text-8xl"></i>
           </div>
           <h2 className="text-3xl font-black tracking-tight">Open New Dossier</h2>
           <p className="text-slate-400 text-sm mt-1 font-medium">Initiate a maritime export operation by providing the core shipment details.</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Main Reference (PO / Booking)</label>
              <input 
                required
                type="text" 
                name="reference"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none focus:border-indigo-500 transition-all"
                placeholder="e.g. BK-2024-X112"
                value={formData.reference}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Destination Port/City</label>
              <input 
                required
                type="text" 
                name="destination"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500/20 focus:outline-none focus:border-indigo-500 transition-all"
                placeholder="e.g. Valencia, Spain"
                value={formData.destination}
                onChange={handleChange}
              />
            </div>
            
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Incoterm</label>
              <select 
                name="incoterm"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-indigo-500"
                value={formData.incoterm}
                onChange={handleChange}
              >
                <option value="EXW">EXW - Ex Works</option>
                <option value="FOB">FOB - Free On Board</option>
                <option value="CIF">CIF - Cost, Insurance & Freight</option>
                <option value="DAP">DAP - Delivered At Place</option>
              </select>
            </div>

            {/* Transport Mode Selection */}
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Transport Mode</label>
              <div className="flex space-x-4">
                <label className="flex items-center space-x-2 cursor-pointer bg-slate-50 px-4 py-2.5 rounded-xl border border-slate-200 has-[:checked]:border-indigo-500 has-[:checked]:bg-indigo-50 has-[:checked]:text-indigo-700 transition-all flex-1 justify-center">
                  <input 
                    type="radio" 
                    name="transportMode" 
                    value="CONTAINER" 
                    checked={formData.transportMode !== 'CAMION'} // Default to Container if undefined
                    onChange={handleChange}
                    className="hidden"
                  />
                  <i className="fa-solid fa-box-open"></i>
                  <span className="text-sm font-bold">Container</span>
                </label>
                <label className="flex items-center space-x-2 cursor-pointer bg-slate-50 px-4 py-2.5 rounded-xl border border-slate-200 has-[:checked]:border-indigo-500 has-[:checked]:bg-indigo-50 has-[:checked]:text-indigo-700 transition-all flex-1 justify-center">
                  <input 
                    type="radio" 
                    name="transportMode" 
                    value="CAMION" 
                    checked={formData.transportMode === 'CAMION'} 
                    onChange={handleChange}
                    className="hidden"
                  />
                  <i className="fa-solid fa-truck-front"></i>
                  <span className="text-sm font-bold">Truck / Camion</span>
                </label>
              </div>
            </div>

            {/* Conditional Transport Fields */}
            {formData.transportMode === 'CAMION' ? (
              <div className="col-span-2 space-y-2 animate-in fade-in slide-in-from-top-2 duration-300">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Truck License Plate (Matricule)</label>
                <input 
                  type="text" 
                  name="truckPlate"
                  required={formData.transportMode === 'CAMION'}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all"
                  placeholder="e.g. 1234-A-50"
                  value={formData.truckPlate || ''}
                  onChange={handleChange}
                />
              </div>
            ) : (
              <div className="col-span-2 space-y-2 animate-in fade-in slide-in-from-top-2 duration-300">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Planned Containers</label>
                <div className="flex space-x-2">
                  <input 
                    type="number" 
                    name="plannedContainers"
                    min="1"
                    className="w-1/3 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-indigo-500"
                    value={formData.plannedContainers}
                    onChange={handleChange}
                  />
                  <select 
                    name="containerType"
                    className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-indigo-500"
                    value={formData.containerType}
                    onChange={handleChange}
                  >
                    <option value="20ST">20' Standard</option>
                    <option value="40ST">40' Standard</option>
                    <option value="40HC">40' High Cube</option>
                    <option value="40RF">40' Reefer</option>
                  </select>
                </div>
              </div>
            )}

            <div className="col-span-2 space-y-2 pt-4 border-t border-slate-100">
               <h3 className="text-xs font-bold text-slate-900 uppercase tracking-widest">Parties Involved</h3>
            </div>

            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Supplier</label>
              <input 
                type="text" 
                name="supplier"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                value={formData.supplier}
                onChange={handleChange}
              />
            </div>
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Consignee</label>
              <input 
                required
                type="text" 
                name="consignee"
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm"
                placeholder="Buyer Name"
                value={formData.consignee}
                onChange={handleChange}
              />
            </div>

            <div className="col-span-2 space-y-2">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">Internal Notes</label>
              <textarea 
                name="notes"
                rows={3}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none"
                placeholder="Any specific logistics requirements..."
                value={formData.notes}
                onChange={handleChange}
              ></textarea>
            </div>
          </div>

          <div className="flex items-center justify-end space-x-4 pt-6">
            <button 
              type="button" 
              onClick={onCancel}
              className="px-6 py-2.5 rounded-xl text-slate-600 font-bold text-sm hover:bg-slate-100 transition-all"
            >
              Cancel
            </button>
            <button 
              type="submit" 
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-indigo-600/30 transition-all"
            >
              Create Dossier
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateDossier;