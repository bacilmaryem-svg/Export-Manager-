import React, { useState, useMemo } from 'react';
import { Dossier, DossierStatus, UserRole, Document, Lot } from '../types';

interface DossierDetailProps {
  dossier: Dossier;
  role: UserRole;
  onUpdate: (updates: Partial<Dossier>) => void;
}

const Stepper: React.FC<{ currentStatus: DossierStatus }> = ({ currentStatus }) => {
  const steps = [
    DossierStatus.DRAFT,
    DossierStatus.WAITING_PRODUCTION_LOTS,
    DossierStatus.LOTS_APPROVED,
    DossierStatus.PL_READY,
    DossierStatus.READY_FOR_DECLARATION,
    DossierStatus.SUBMITTED,
    DossierStatus.CLEARED
  ];

  const getStepLabel = (step: DossierStatus) => {
    switch (step) {
      case DossierStatus.READY_FOR_DECLARATION: return "GOV PORTAL PREP";
      case DossierStatus.SUBMITTED: return "SUBMITTED";
      case DossierStatus.CLEARED: return "ACCEPTED";
      default: return step.replace(/_/g, ' ').replace('WAITING ', '');
    }
  };

  const currentIndex = steps.indexOf(currentStatus);
  // Handle statuses that aren't in the linear path (like BLOCKED)
  const displayIndex = currentIndex === -1 ? steps.length - 1 : currentIndex;

  return (
    <div className="flex items-center w-full px-4 py-8 overflow-x-auto no-scrollbar">
      {steps.map((step, index) => {
        const isCompleted = index < displayIndex;
        const isCurrent = index === displayIndex;
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const isPending = index > displayIndex;

        return (
          <React.Fragment key={step}>
            <div className="flex flex-col items-center relative min-w-[100px]">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all ${
                isCompleted ? 'bg-indigo-600 border-indigo-600 text-white' :
                isCurrent ? 'border-indigo-600 text-indigo-600 shadow-lg shadow-indigo-600/20' :
                'bg-white border-slate-200 text-slate-400'
              }`}>
                {isCompleted ? <i className="fa-solid fa-check text-xs"></i> : <span className="text-[10px] font-bold">{index + 1}</span>}
              </div>
              <span className={`mt-2 text-[9px] font-bold uppercase tracking-wider text-center ${isCurrent ? 'text-indigo-600' : 'text-slate-400'}`}>
                {getStepLabel(step)}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div className={`flex-1 h-[2px] min-w-[30px] mx-2 mb-6 ${index < displayIndex ? 'bg-indigo-600' : 'bg-slate-200'}`}></div>
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
};

const SummaryTab: React.FC<{ dossier: Dossier }> = ({ dossier }) => (
  <div className="grid grid-cols-3 gap-8">
    <div className="col-span-2 space-y-8">
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Supplier</p>
          <p className="text-sm font-bold text-slate-900">{dossier.supplier}</p>
        </div>
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Consignee</p>
          <p className="text-sm font-bold text-slate-900">{dossier.consignee}</p>
        </div>
      </div>

      <div>
        <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest mb-4 flex items-center">
          <i className="fa-solid fa-chart-pie mr-2 text-indigo-500"></i>
          Dossier Totals
        </h4>
        <div className="grid grid-cols-4 gap-4">
          <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-sm text-center">
             <p className="text-2xl font-black text-slate-900">{dossier.totalCartons}</p>
             <p className="text-[10px] font-bold text-slate-500 uppercase">Cartons</p>
          </div>
          <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-sm text-center">
             <p className="text-2xl font-black text-slate-900">{dossier.totalNet}kg</p>
             <p className="text-[10px] font-bold text-slate-500 uppercase">Total Net</p>
          </div>
          <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-sm text-center">
             <p className="text-2xl font-black text-slate-900">{dossier.totalGross}kg</p>
             <p className="text-[10px] font-bold text-slate-500 uppercase">Total Gross</p>
          </div>
          <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-2xl shadow-sm text-center">
             <p className="text-2xl font-black text-indigo-600">${dossier.totalValue.toLocaleString()}</p>
             <p className="text-[10px] font-bold text-indigo-500 uppercase">Invoice Value</p>
          </div>
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-100 p-6 rounded-2xl">
         <h4 className="text-xs font-black text-amber-800 uppercase tracking-widest mb-2">Internal Notes</h4>
         <p className="text-sm text-amber-700 leading-relaxed font-medium">
           {dossier.notes || "No special instructions recorded for this shipment."}
         </p>
      </div>
    </div>

    <div className="space-y-6">
      <div className="bg-slate-900 rounded-2xl p-6 text-white overflow-hidden relative">
         <div className="absolute top-0 right-0 -mr-8 -mt-8 w-32 h-32 bg-indigo-500 opacity-20 rounded-full"></div>
         <h4 className="text-xs font-black uppercase tracking-widest mb-6 opacity-60">Logistics Context</h4>
         <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-xs text-slate-400 font-medium">Booking ID:</span>
              <span className="text-xs font-bold">{dossier.reference}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs text-slate-400 font-medium">Incoterm:</span>
              <span className="text-xs font-bold text-indigo-400">{dossier.incoterm}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs text-slate-400 font-medium">Containers:</span>
              <span className="text-xs font-bold">{dossier.plannedContainers} x {dossier.containerType}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-xs text-slate-400 font-medium">Created:</span>
              <span className="text-xs font-bold">{dossier.createdAt}</span>
            </div>
         </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-2xl p-6">
         <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest mb-6">Recent Activities</h4>
         <div className="space-y-4">
            <div className="flex items-start space-x-3">
               <div className="w-2 h-2 rounded-full bg-indigo-600 mt-1.5"></div>
               <div>
                  <p className="text-xs font-bold text-slate-900">Document "Invoice.pdf" uploaded</p>
                  <p className="text-[10px] text-slate-500">2 hours ago by John Ops</p>
               </div>
            </div>
         </div>
      </div>
    </div>
  </div>
);

const DocumentsTab: React.FC<{ dossier: Dossier }> = ({ dossier }) => {
  const [docs] = useState<Document[]>([
    { id: '1', type: 'Commercial Invoice', status: 'VALIDATED', fileName: 'INV-5521.pdf', mandatory: true },
    { id: '2', type: 'Packing List', status: 'PENDING', fileName: 'PL-5521_Draft.pdf', mandatory: true },
    { id: '3', type: 'VGM Certificate', status: 'MISSING', mandatory: true },
  ]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
         <h3 className="text-lg font-bold text-slate-900">Compliance Documents</h3>
         <button className="text-indigo-600 font-bold text-sm flex items-center space-x-2 bg-indigo-50 px-4 py-2 rounded-xl border border-indigo-100">
            <i className="fa-solid fa-upload"></i>
            <span>Upload New Document</span>
         </button>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {docs.map(doc => (
          <div key={doc.id} className={`p-4 rounded-2xl border transition-all ${
            doc.status === 'VALIDATED' ? 'bg-green-50 border-green-100' :
            doc.status === 'MISSING' && doc.mandatory ? 'bg-rose-50 border-rose-100 animate-pulse' :
            'bg-white border-slate-200'
          }`}>
             <div className="flex items-start justify-between mb-3">
                <i className={`fa-solid ${doc.fileName ? 'fa-file-pdf text-rose-500' : 'fa-file-circle-plus text-slate-300'} text-2xl`}></i>
                {doc.mandatory && <span className="text-[8px] font-black text-white bg-slate-900 px-1.5 py-0.5 rounded uppercase tracking-tighter">Required</span>}
             </div>
             <p className="text-xs font-black text-slate-900 truncate">{doc.type}</p>
             <p className="text-[10px] text-slate-500 font-bold mt-1 uppercase tracking-tight">{doc.status}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

const ProductionTab: React.FC<{ dossier: Dossier, onUpdate: (s: DossierStatus) => void }> = ({ dossier, onUpdate }) => {
  const [lots] = useState<Lot[]>([
    { id: 'LOT-A102', product: 'Frozen Atlantic Salmon', size: '2-3kg', prodDate: '2024-04-12', expiryDate: '2025-10-12', stockCartons: 450, stockKg: 9000, conforming: true, selected: true },
  ]);

  const allApproved = dossier.status === DossierStatus.LOTS_APPROVED || dossier.status === DossierStatus.PL_READY;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
         <h3 className="text-lg font-bold text-slate-900">Production Inventory</h3>
         {!allApproved ? (
            <button onClick={() => onUpdate(DossierStatus.LOTS_APPROVED)} className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold text-sm">Approve Lots</button>
         ) : (
            <button onClick={() => onUpdate(DossierStatus.PL_READY)} className="bg-green-600 text-white px-5 py-2.5 rounded-xl font-bold text-sm">Generate Final PL</button>
         )}
      </div>
      <div className="overflow-hidden border border-slate-200 rounded-xl">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-[10px] font-bold text-slate-500 uppercase">Select</th>
              <th className="px-4 py-3 text-[10px] font-bold text-slate-500 uppercase">Lot ID</th>
              <th className="px-4 py-3 text-[10px] font-bold text-slate-500 uppercase">Stock</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {lots.map(lot => (
              <tr key={lot.id}>
                <td className="px-4 py-4"><input type="checkbox" checked={lot.selected} readOnly className="rounded text-indigo-600" /></td>
                <td className="px-4 py-4 font-bold">{lot.id}</td>
                <td className="px-4 py-4">{lot.stockCartons} Cartons / {lot.stockKg} kg</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const LogisticsTab: React.FC<{ dossier: Dossier, onUpdate: (s: DossierStatus) => void }> = ({ dossier, onUpdate }) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
         <h3 className="text-lg font-bold text-slate-900">Containers & VGM</h3>
         {dossier.status === DossierStatus.PL_READY && (
            <button onClick={() => onUpdate(DossierStatus.VGM_READY)} className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold text-sm">Certify All VGM</button>
         )}
      </div>
      <div className="bg-white border border-slate-200 rounded-2xl p-6">
          <p className="text-sm font-medium text-slate-600">Enter container details and upload VGM certificates to proceed.</p>
      </div>
    </div>
  );
};

// GOV PORTAL TAB
const GovPortalTab: React.FC<{ dossier: Dossier, role: UserRole, onUpdate: (updates: Partial<Dossier>) => void }> = ({ dossier, role, onUpdate }) => {
  const isDeclarant = role === UserRole.DECLARANT_ETAT;
  
  const [formData, setFormData] = useState({
    dum: dossier.dum || '',
    besc: dossier.besc || '',
    submissionDate: dossier.submissionDate || new Date().toISOString().split('T')[0],
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleStatusUpdate = (newStatus: DossierStatus) => {
    onUpdate({ status: newStatus, ...formData });
  };

  const canSubmit = formData.dum.length > 5;

  return (
    <div className="space-y-8">
      {/* Header Info */}
      <div className="bg-slate-900 rounded-2xl p-8 text-white relative overflow-hidden">
         <div className="absolute top-0 right-0 p-8 opacity-10">
            <i className="fa-solid fa-building-columns text-8xl"></i>
         </div>
         <div className="relative z-10">
            <h3 className="text-2xl font-black tracking-tight">Gov Portal Upload Hub</h3>
            <p className="text-slate-400 text-sm mt-1 max-w-xl">
               Declaration is performed on the government portal <strong>outside this application</strong>. 
               Upload the resulting documents and official reference numbers here to finalize the dossier.
            </p>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
         {/* SECTION A: Preparation & Pack */}
         <div className="space-y-6">
            <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center">
               <i className="fa-solid fa-box-archive mr-2 text-indigo-500"></i>
               1. Preparation Check
            </h4>
            
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-4">
               <ul className="space-y-3">
                  <li className="flex items-center space-x-3 text-xs font-bold text-slate-700">
                     <i className="fa-solid fa-circle-check text-green-500"></i>
                     <span>Commercial Invoice Attached</span>
                  </li>
                  <li className="flex items-center space-x-3 text-xs font-bold text-slate-700">
                     <i className="fa-solid fa-circle-check text-green-500"></i>
                     <span>Packing List Validated</span>
                  </li>
                  <li className="flex items-center space-x-3 text-xs font-bold text-slate-700">
                     <i className={`fa-solid ${dossier.status !== DossierStatus.DRAFT ? 'fa-circle-check text-green-500' : 'fa-circle-xmark text-slate-300'}`}></i>
                     <span>VGM Data Certified</span>
                  </li>
               </ul>

               <div className="pt-4 border-t border-slate-200">
                  <p className="text-[10px] font-bold text-slate-500 uppercase mb-3">Export Pack (ZIP)</p>
                  <button className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold text-xs flex items-center justify-center space-x-2 hover:bg-indigo-700 transition-all">
                     <i className="fa-solid fa-file-zipper"></i>
                     <span>Download Dossier Pack</span>
                  </button>
               </div>
            </div>
         </div>

         {/* SECTION B & C: State Portal Inputs */}
         <div className="lg:col-span-2 space-y-8">
            <div className="bg-white border border-slate-200 rounded-2xl p-8 space-y-8">
               
               {/* Upload Slots */}
               <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest mb-4">2. Upload State-Issued Documents</h4>
                  <div className="grid grid-cols-2 gap-4">
                     <div className={`p-4 rounded-xl border-2 border-dashed flex flex-col items-center justify-center space-y-2 transition-all ${isDeclarant ? 'border-indigo-100 bg-indigo-50/20' : 'border-slate-100 bg-slate-50/50 opacity-60'}`}>
                        <i className="fa-solid fa-file-pdf text-xl text-slate-400"></i>
                        <span className="text-[10px] font-black uppercase text-slate-500">DUM Document (PDF)</span>
                        {isDeclarant && <button className="text-[9px] font-bold text-indigo-600 underline">Upload File</button>}
                     </div>
                     <div className={`p-4 rounded-xl border-2 border-dashed flex flex-col items-center justify-center space-y-2 transition-all ${isDeclarant ? 'border-slate-200 bg-white' : 'border-slate-100 bg-slate-50/50 opacity-60'}`}>
                        <i className="fa-solid fa-file-pdf text-xl text-slate-400"></i>
                        <span className="text-[10px] font-black uppercase text-slate-500">BESC Document (Optional)</span>
                        {isDeclarant && <button className="text-[9px] font-bold text-indigo-600 underline">Upload File</button>}
                     </div>
                  </div>
               </div>

               {/* Reference Fields */}
               <div>
                  <h4 className="text-xs font-black text-slate-900 uppercase tracking-widest mb-4">3. Official Reference Numbers</h4>
                  <div className="grid grid-cols-2 gap-6">
                     <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">DUM Number (Required)</label>
                        <input 
                           disabled={!isDeclarant}
                           name="dum"
                           value={formData.dum}
                           onChange={handleInputChange}
                           className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-indigo-500/20 focus:outline-none" 
                           placeholder="e.g. DUM-2024-5510"
                        />
                     </div>
                     <div className="space-y-1.5">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Submission Date</label>
                        <input 
                           disabled={!isDeclarant}
                           name="submissionDate"
                           type="date"
                           value={formData.submissionDate}
                           onChange={handleInputChange}
                           className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold focus:outline-none"
                        />
                     </div>
                     <div className="col-span-2 space-y-1.5">
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">BESC / ECTN (Optional)</label>
                        <input 
                           disabled={!isDeclarant}
                           name="besc"
                           value={formData.besc}
                           onChange={handleInputChange}
                           className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold focus:outline-none" 
                           placeholder="e.g. BESC-NY-123"
                        />
                     </div>
                  </div>
               </div>

               {/* Action Buttons for Declarant */}
               {isDeclarant && (
                  <div className="pt-6 border-t border-slate-100 flex items-center justify-end space-x-4">
                     <button 
                        onClick={() => handleStatusUpdate(DossierStatus.BLOCKED)}
                        className="px-6 py-3 bg-rose-50 text-rose-700 rounded-xl font-bold text-xs hover:bg-rose-100 transition-all border border-rose-100"
                     >
                        Mark as Rejected
                     </button>
                     <button 
                        disabled={!canSubmit}
                        onClick={() => handleStatusUpdate(DossierStatus.SUBMITTED)}
                        className={`px-8 py-3 rounded-xl font-bold text-xs transition-all shadow-lg ${
                           canSubmit ? 'bg-indigo-600 text-white shadow-indigo-600/20' : 'bg-slate-200 text-slate-400 cursor-not-allowed shadow-none'
                        }`}
                     >
                        Mark as Submitted
                     </button>
                     {dossier.status === DossierStatus.SUBMITTED && (
                        <button 
                           onClick={() => handleStatusUpdate(DossierStatus.CLEARED)}
                           className="px-8 py-3 bg-emerald-600 text-white rounded-xl font-bold text-xs shadow-lg shadow-emerald-600/20"
                        >
                           Mark Accepted / Cleared
                        </button>
                     )}
                  </div>
               )}

               {!isDeclarant && dossier.status === DossierStatus.READY_FOR_DECLARATION && (
                  <div className="p-4 bg-amber-50 border border-amber-100 rounded-xl flex items-center space-x-3">
                     <i className="fa-solid fa-clock text-amber-500"></i>
                     <p className="text-xs font-bold text-amber-800">Awaiting State Declarant to upload Gov Portal documents.</p>
                  </div>
               )}
            </div>
         </div>
      </div>
    </div>
  );
};

const DossierDetail: React.FC<DossierDetailProps> = ({ dossier, role, onUpdate }) => {
  const [activeTab, setActiveTab] = useState<'SUMMARY' | 'DOCS' | 'PROD' | 'LOGISTICS' | 'DECLARATION'>('SUMMARY');

  const tabs = [
    { id: 'SUMMARY', label: 'Summary', icon: 'fa-circle-info' },
    { id: 'DOCS', label: 'Documents', icon: 'fa-file-lines' },
    { id: 'PROD', label: 'Production & PL', icon: 'fa-boxes-stacked' },
    { id: 'LOGISTICS', label: 'Logistics & VGM', icon: 'fa-truck-container' },
    { id: 'DECLARATION', label: 'State Documents', icon: 'fa-building-columns' },
  ];

  const canMarkReadyToDeclare = useMemo(() => {
    // Basic logic: Need PL ready and VGM ready to move to "Ready for Gov Portal"
    return dossier.status === DossierStatus.VGM_READY || dossier.status === DossierStatus.REGULATORY_READY;
  }, [dossier.status]);

  const handleStatusChange = (newStatus: DossierStatus) => {
    onUpdate({ status: newStatus });
  };

  const getDossierStatusLabel = (s: DossierStatus) => {
    if (s === DossierStatus.READY_FOR_DECLARATION) return "READY FOR GOV PORTAL";
    if (s === DossierStatus.CLEARED) return "ACCEPTED / CLEARED";
    return s.replace(/_/g, ' ');
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-500 h-full flex flex-col">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center space-x-3">
             <h2 className="text-3xl font-black text-slate-900 tracking-tight">{dossier.id}</h2>
             <span className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-widest border shadow-sm ${
               dossier.status === DossierStatus.BLOCKED ? 'bg-rose-100 text-rose-700 border-rose-200' : 'bg-indigo-50 text-indigo-700 border-indigo-200'
             }`}>
               {getDossierStatusLabel(dossier.status)}
             </span>
          </div>
          <p className="text-slate-500 font-medium text-sm mt-1">
            Destination: <span className="text-slate-900 font-bold">{dossier.destination}</span> • Ref: <span className="text-slate-900 font-bold">{dossier.reference}</span>
          </p>
        </div>

        <div className="flex items-center space-x-3">
          {role === UserRole.EXPORT_OPS && dossier.status === DossierStatus.DRAFT && (
            <button 
              onClick={() => handleStatusChange(DossierStatus.WAITING_PRODUCTION_LOTS)}
              className="bg-indigo-600 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-indigo-600/30 transition-all"
            >
              Request Production Lots
            </button>
          )}

          {role === UserRole.EXPORT_OPS && canMarkReadyToDeclare && dossier.status !== DossierStatus.READY_FOR_DECLARATION && (
            <button 
              onClick={() => handleStatusChange(DossierStatus.READY_FOR_DECLARATION)}
              className="bg-green-600 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-green-600/30 transition-all flex items-center space-x-2"
            >
              <i className="fa-solid fa-check-double"></i>
              <span>Mark Ready for Gov Portal</span>
            </button>
          )}
          
          <button className="bg-white border border-slate-200 text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 transition-all">
             <i className="fa-solid fa-ellipsis-vertical"></i>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200">
         <Stepper currentStatus={dossier.status} />
      </div>

      <div className="flex-1 flex flex-col min-h-0 bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="flex border-b border-slate-100 bg-slate-50/50">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-6 py-4 flex items-center space-x-2 text-sm font-bold transition-all border-b-2 ${
                activeTab === tab.id ? 'text-indigo-600 border-indigo-600 bg-white' : 'text-slate-400 border-transparent hover:text-slate-600'
              }`}
            >
              <i className={`fa-solid ${tab.icon}`}></i>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'SUMMARY' && <SummaryTab dossier={dossier} />}
          {activeTab === 'DOCS' && <DocumentsTab dossier={dossier} />}
          {activeTab === 'PROD' && <ProductionTab dossier={dossier} onUpdate={handleStatusChange} />}
          {activeTab === 'LOGISTICS' && <LogisticsTab dossier={dossier} onUpdate={handleStatusChange} />}
          {activeTab === 'DECLARATION' && <GovPortalTab dossier={dossier} role={role} onUpdate={onUpdate} />}
        </div>
      </div>
    </div>
  );
};

export default DossierDetail;