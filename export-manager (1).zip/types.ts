export enum UserRole {
  EXPORT_OPS = 'EXPORT_OPS',
  DECLARANT_ETAT = 'DECLARANT_ETAT'
}

export enum DossierStatus {
  DRAFT = 'DRAFT',
  WAITING_PRODUCTION_LOTS = 'WAITING_PRODUCTION_LOTS',
  LOTS_APPROVED = 'LOTS_APPROVED',
  PL_READY = 'PL_READY',
  VGM_READY = 'VGM_READY',
  REGULATORY_READY = 'REGULATORY_READY',
  READY_FOR_DECLARATION = 'READY_FOR_DECLARATION',
  SUBMITTED = 'SUBMITTED',
  CLEARED = 'CLEARED',
  BLOCKED = 'BLOCKED'
}

export interface Lot {
  id: string;
  product: string;
  size: string;
  prodDate: string;
  expiryDate: string;
  stockCartons: number;
  stockKg: number;
  conforming: boolean;
  selected: boolean;
}

export interface Container {
  id: string;
  type: string;
  seal?: string;
  vgm?: number;
}

export interface Document {
  id: string;
  type: string;
  status: 'MISSING' | 'PENDING' | 'VALIDATED';
  fileName?: string;
  mandatory: boolean;
}

export interface Dossier {
  id: string;
  reference: string;
  destination: string;
  incoterm: string;
  supplier: string;
  consignee: string;
  plannedContainers: number;
  containerType: string;
  notes: string;
  status: DossierStatus;
  lastUpdated: string;
  createdAt: string;
  
  // Transport Data
  transportMode?: 'CONTAINER' | 'CAMION';
  truckPlate?: string;

  // Calculated/Production Data
  totalCartons: number;
  totalNet: number;
  totalGross: number;
  totalValue: number;

  // Gov Portal Data
  dum?: string;
  besc?: string;
  submissionDate?: string;
}